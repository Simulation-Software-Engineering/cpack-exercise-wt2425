#pragma once

#include<string>

void parseConfig(const std::string yamlFile);
