#pragma once

void inspectDirectory();
